let StateData: RootDataType = {
    profilePage: {
        postData: [
            {id: 1, message: 'Hi how are u', likes: 10},
            {id: 2, message: 'Hey, are u fine?', likes: 11},
            {id: 3, message: 'Bye bye', likes: 8},
        ]
    },
    messagePage: {
        dialogsData: [
            {id: 1, name: 'Dimych'},
            {id: 2, name: 'Slavik'},
            {id: 3, name: 'Valera'},
            {id: 1, name: 'Dimych'},
            {id: 2, name: 'Slavik'},
            {id: 3, name: 'Valera'}
        ],
        messagesData: [
            {id: 1, message: 'Yo'},
            {id: 2, message: 'osfgsag'},
            {id: 3, message: 'VSVQWfqwfqwf'},
            {id: 1, message: 'Yo'},
            {id: 2, message: 'osfgsag'},
            {id: 3, message: 'VSVQWfqwfqwf'}
        ],
    },
    sidebar: {
        menuLinks: [
            {id: 1, name: 'MainPage', link: '/mainpage'},
            {id: 2, name: 'Dialogs', link: '/dialogs'},
            {id: 3, name: 'News', link: '/news'}
        ],
        friendsList: [
            {id: 1, name: 'Igor', avatarLink: 'https://icons.iconarchive.com/icons/sonya/swarm/256/Cat-icon.png'},
            {id: 2, name: 'Valera', avatarLink: 'https://icons.iconarchive.com/icons/sonya/swarm/256/Cat-icon.png'},
            {id: 3, name: 'Semen', avatarLink: 'https://icons.iconarchive.com/icons/sonya/swarm/256/Cat-icon.png'},
        ]
    }
}

// export const addPost = (postMessage: string) => {
//     const newPost:newPostType  = {
//         id: 5,
//         message: postMessage,
//         likes: 0
//     }
//
//     StateData.profilePage.postData.push(newPost)
// }


export type StateType = {
    state: RootDataType

}
export type RootDataType = {
    profilePage: profilePageType
    messagePage: messagePageType
    sidebar: SidebarType

}
export type SidebarType = {
    menuLinks: Array<menuLinks>
    friendsList: Array<friendsList>
}
export type profilePageType = {
    postData: Array<newPostType>

}

export type messagePageType = {
    dialogsData: Array<dialogsData>
    messagesData: Array<messagesData>

}
export type newPostType = {
    id: number
    message: string
    likes: number
}

export type dialogsData = {
    id: number
    name: string
}
export type messagesData = {
    id: number
    message: string
}
export type menuLinks = {
    id: number
    name: string
    link: string
}
export type friendsList = {
    id: number
    name: string
    avatarLink: string
}




export default StateData;
