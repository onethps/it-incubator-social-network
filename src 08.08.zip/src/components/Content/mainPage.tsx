import React from "react";
import style from './content.module.css';
import {Mymessage} from "../Profile/MyPosts/Mymessage";
import {Profile} from "../Profile/Profile";
import {ProfileInfo} from "../Profile/ProfileInfo/ProfileInfo";
import {profilePageType, RootDataType} from "../../redux/state";





export function MainPage(props:profilePageType) {
    return <main className={style.content}>

        <ProfileInfo/>
        <Mymessage postData={props.postData}/>


    </main>
}