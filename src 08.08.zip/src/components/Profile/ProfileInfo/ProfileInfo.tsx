import React from "react";
import s from "./ProfileInfo.module.css";

export const ProfileInfo = () => {
    return (
        <div>
            <div>
                <img
                    src='https://pickydigest.com/wp-content/uploads/2017/05/fb-fanpage-cover-photo-strategies-and-tips_image11-1422x200.png'>
                </img>
            </div>
            <div>
                ava + text
            </div>

        </div>
    )
}