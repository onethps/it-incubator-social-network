import s from './Profile.module.css'
import React from "react";

type PropsMessageType = {
    message: string
    likesCount: number
}


export const Profile: React.FC<PropsMessageType> = (props) => {
    return <div>
        <img className={s.icon} src='https://icons.iconarchive.com/icons/sonya/swarm/256/Cat-icon.png'></img>
        <div className={s.message}>{props.message}</div>
        <div>likes</div>
        <div className={s.likes}>{props.likesCount}</div>
        </div>

}