import s from './Mymessage.module.css';
import {Profile} from "../Profile";
import React, {LegacyRef, RefObject} from "react";
import {profilePageType} from "../../../redux/state";


export const Mymessage: React.FC<profilePageType> = (props) => {

    let postsElems = props.postData.map(p =>
        <div>
            <Profile message={p.message} likesCount={p.likes}/>
        </div>)

    //
    // let newPostElem = React.createRef<HTMLTextAreaElement>();
    //
    // let addPost = () => {
    //     if (newPostElem.current) {
    //         // props.addPost(newPostElem.current?.value)
    //     }
    // }

    return (
        <div>
            My Messages
            <div className={s.Mymessage}>
                {/*<textarea ref={newPostElem}></textarea>*/}
                <textarea ></textarea>
                {/*<button onClick={addPost}>Add Post</button>*/}
                <button >Add Post</button>
                {postsElems}
            </div>

        </div>
    )
}


