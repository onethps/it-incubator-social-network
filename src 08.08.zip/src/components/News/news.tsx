export const News = () => {
    return (
        <div>
            News
        </div>
    )
}