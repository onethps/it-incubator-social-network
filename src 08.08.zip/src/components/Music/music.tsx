export const Music = () => {
    return (
        <div>
            Music
        </div>
    )
}