import React, {FC} from "react";
import s from './dialogs.module.css'
import {DialogItem} from "./DialogItem/DialogItem";
import {MessageItem} from "./MessageItem/MessageItem";
import {messagePageType} from "../../redux/state";

export const Dialogs: React.FC<messagePageType> = (props) => {


    let friendsElems =
        props.dialogsData.map(d => <DialogItem name={d.name} id={d.id}/>)

    let messageElems =
        props.messagesData.map(m => <MessageItem message={m.message}/>)

    const refTextAreaMessage = React.createRef<HTMLTextAreaElement>();


    const sendNewPost = () => {

        alert(refTextAreaMessage.current?.value)
    }

    return (
        <div>
            <div className={s.containerBlock}>

                <div className={s.friendsListBlock}>
                    {friendsElems}
                </div>

                <div className={s.messageAndTexBlock}>
                    <div>
                        {messageElems}
                    </div>
                    <div className={s.newMessageBlock}>
                        <textarea ref={refTextAreaMessage} className={s.textArea}/>
                        <button onClick={sendNewPost} className={s.sendButton}> Add Message</button>
                    </div>
                </div>
            </div>

        </div>

    )
}
